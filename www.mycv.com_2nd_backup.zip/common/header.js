document.write(' <meta charset="UTF-8">'+
'<meta name="viewport" content="width=device-width, initial-scale=1.0">' +
'<meta name="description" content="Abdus Salam CV Resume">'+
'<meta name="author" content="AbdusSalam">'+
'<link rel="shortcut icon" href="images/fav.png" type="image/png">'+
'<link rel="stylesheet" href="css/main.css" media="screen">'+
'<link rel="stylesheet" href="css/flexslider.css" media="screen">'+
'<link rel="stylesheet" href="css/fancybox-light.css" media="screen">'+
'<link rel="stylesheet" href="css/fontawesome/css/all.min.css" type="text/css">' +
'<link rel="stylesheet" href="./css/css.css" type="text/css">' +
 '<link href=\'http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,400,300,600,700\'    rel=\'stylesheet\' type=\'text/css\'>'+
 '<audio><source src="audio/sound.mp3"/></audio>'
);

