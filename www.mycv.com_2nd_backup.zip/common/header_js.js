document.write(
'<script src="./js/jquery.hoverfold.js"></script>'+
'<script src="./js/jquery-1.8.3.min.js"></script>'+
'<script src="js/jquery.isotope.min.js"></script>'+
'<script src="js/modernizr.custom.js"></script>'+
'<script src="./js/js.js"></script>'+
'<script src="http://maps.google.com/maps/api/js?sensor=false&amp;language=en"></script>'+
'<script>if (window.location.hash.indexOf("#!") !== -1) window.location.hash = "";</script>'+
'<script type="text/javascript" charset="UTF-8" src="./js/common.js"></script>'+
'<script type="text/javascript" charset="UTF-8" src="./js/util.js"></script>');