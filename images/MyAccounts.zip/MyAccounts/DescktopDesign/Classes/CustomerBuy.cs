﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesktopDesign.Classes
{
	public class CustomerBuy
	{
		public string Invoice { get; set; }
		public double Total { get; set; }
		public double TotalDiscount { get; set; }
		public double Vat { get; set; }
		public double Paid { get; set; }
		public double PaidNote { get; set; }
		public short PaymnetMethod { get; set; }
		public string InputDateTime { get; set; }
		public List<CustomerBuyDetails> CustomerBuyDetailsList { get; set; }
		public Customer Customer { get; set; }
	}
}
