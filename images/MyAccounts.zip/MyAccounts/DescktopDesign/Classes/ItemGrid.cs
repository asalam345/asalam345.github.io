﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesktopDesign.Classes
{
	public class ItemGrid
	{
		public long ItemId { get; set; }
		public string ItemCode { get; set; }
		public string ItemName { get; set; }
		public double PurchasePrice { get; set; }
		public double OtherCost { get; set; }
		public double SellPrice { get; set; }
		public double Quantity { get; set; }
		public double TakeQuantity { get; set; }
		public double DiscountPrice { get; set; }
		public double Amount { get; set; }
		public string Description { get; set; }
		public short UnitID { get; set; }
		public DateTime CreateDate { get; set; }
		public DateTime UpdateDate { get; set; }
		public string CreateTime { get; set; }
		public string UpdateTime { get; set; }
	}
}
