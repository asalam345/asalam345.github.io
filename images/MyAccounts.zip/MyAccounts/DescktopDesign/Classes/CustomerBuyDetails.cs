﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesktopDesign.Classes
{
	public class CustomerBuyDetails
	{
		public string Invoice { get; set; }
		public long ProductId { get; set; }
		public double Quantity { get; set; }
		public double Discount { get; set; }
	}
}
