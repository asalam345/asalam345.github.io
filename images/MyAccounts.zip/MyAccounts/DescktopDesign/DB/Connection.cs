﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace DesktopDesign.DB
{
	public class Connection
	{
        public string connectionString;
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();
        DataTable dt = new DataTable();
        int result;
        public Connection()
        {
            AppDomain path = AppDomain.CurrentDomain;
            connectionString = "Server=.;DataBase=AccountManagement;user id=sa;password=sa123";
            conn.ConnectionString = connectionString;
        }
        public bool InsertOrUpdate(string query)
		{
            try
            {
                conn.Open();
                cmd.Connection = conn;
                cmd.CommandText = query;
                //execute the data.
                result = cmd.ExecuteNonQuery();
                //validate the result of the executed query.
                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)//catch exeption
            {
                exceptionHandel("Connection", "InsertOrUpdate", ex.ToString());
                return false;
            }
			finally
			{
                conn.Close();
            }
        }
        public DataTable GetData(string query)
        {
            try
            {
                //create a query for retrieving data in the database.
                //query = "SELECT ID as 'Id',NAME as 'Name',UNAME as 'Username', UTYPE as 'Role',PASS FROM tblcrud";
                //initialize new Sql commands
                cmd = new SqlCommand();
                //hold the data to be executed.
                cmd.Connection = conn;
                cmd.CommandText = query;
                //initialize new Sql data adapter
                da = new SqlDataAdapter();
                //fetching query in the database.
                da.SelectCommand = cmd;
                //initialize new datatable
                dt = new DataTable();
                //refreshes the rows in specified range in the datasource. 
                da.Fill(dt);
                return dt;
                //set the data that to be display in the datagridview
                //dtgList.DataSource = dt;
                //hide the password column in the datagridview 
                //dtgList.Columns["PASS"].Visible = false;
            }
            catch (Exception ex)
            {
                exceptionHandel("Connection", "GetData", ex.ToString());
                return null;
            }
            finally
            {
                da.Dispose();

            }
        }
        public bool Delete(string query)
        {
            try
            {
                conn.Open();
                //it holds the data to be executed.
                cmd.Connection = conn;
                cmd.CommandText = query;
                //execute the data.
                result = cmd.ExecuteNonQuery();
                //validate the result of the executed query.
                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }

            catch (Exception ex)
            {
                exceptionHandel("Connection", "GetData", ex.ToString());
                return false;
            }
            finally
            {
                conn.Close();
            }
        }
        //public DataTable DatabaseConnection(string commandString, out bool result, bool insORup = true)
        //{
        //    result = false;
        //    try
        //    {
        //        dataAdapter = new OleDbDataAdapter(commandString, connectionString);
        //        dataTable = new DataTable();
        //        dataSet = new DataSet();
        //        dataAdapter.Fill(dataSet);
        //        if (!insORup)
        //        {
        //            dataTable = dataSet.Tables[0];
        //        }
        //        result = true;
        //        return dataTable;
        //    }
        //    catch (Exception ex)
        //    {
        //        //exceptionHandel("DatabaseConnection", commandString, ex.ToString(), DateTime.Now);
        //        return null;
        //    }
        //}
        public bool exceptionHandel(string className, string methodName, string ex)
        {
            bool result = false;

            try
            {
                result = InsertOrUpdate("INSERT INTO Exception(ClassName, MethodName, Exp, DateOfEx, TimeOfEx) " +
                    "VALUES('" + className + "', '" + methodName + "', '" + ex + "', '" +
                    DateTime.Now.ToShortDateString() + "', '" + DateTime.Now.ToLongTimeString() + "')");
            }
            catch (Exception e)
            {
                exceptionHandel("Connection", "exceptionHandel", e.ToString());
            }
            return result;
        }
    }
}
