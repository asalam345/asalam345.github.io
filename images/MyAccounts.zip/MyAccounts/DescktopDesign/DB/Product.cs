﻿using DesktopDesign.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace DesktopDesign.DB
{
	public static class Product
	{
		private static Connection con = new Connection();
		public static List<ItemGrid> GetProducts(long id = 0)
		{
			string query = "SELECT * FROM ITEM";
			DataTable dt = con.GetData(query);
			List<ItemGrid> itemGrids = new List<ItemGrid>();
			itemGrids = Converter.ConvertDataTable<ItemGrid>(dt);
			return itemGrids;
		}
		public static bool Save(ItemGrid item)
		{
			string query = @"INSERT INTO ITEM(ITEMCODE, ITEMNAME, QUANTITY, PurchasePrice,
				 OTHERCost, DISCOUNTPRICE, SellPRICE,UNITID,DESCRIPTION,CREATEDATE,CREATETIME,UpdateDate) VALUES 
				 ('" + item.ItemCode + "','" + item.ItemName + "','" + item.Quantity + "'" +
				 ",'" + item.PurchasePrice + "','" + item.OtherCost + "','" + item.DiscountPrice + "'" +
				 ",'" + item.SellPrice + "','" + item.UnitID + "','" + item.Description + "'" +
				 ",'" + DateTime.Now + "','" + DateTime.Now.ToShortTimeString() + "','" + DateTime.Now + "')";
			return con.InsertOrUpdate(query);
		}
		public static bool Update(ItemGrid item)
		{
			string query = @"UPDATE ITME SET ITEMCODE = '" + item.ItemCode + "'," +
				"ITEMNAME = '" + item.ItemName + "', QUANTITY = '" + item.Quantity + "'" +
				",PERCHASEPRICE = '" + item.PurchasePrice + "',OTHERPRICE = '" + item.OtherCost + "'" +
				",DISCOUNTPRICE = '" + item.DiscountPrice + "',SellPRICE='" + item.SellPrice + "'" +
				",UNITID'" + item.UnitID + "',DESCRIPTION'" + item.Description + "'" +
				",UPDATEDATE='" + DateTime.Now + "',UPDATETIME='" + DateTime.Now.ToShortTimeString() + "'";
			return con.InsertOrUpdate(query);
		}
		public static bool Delete(long id)
		{
			string query = "DELETE FROM ITEM WHERE ItemID = " + id;
			return con.Delete(query);
		}
	}
}
