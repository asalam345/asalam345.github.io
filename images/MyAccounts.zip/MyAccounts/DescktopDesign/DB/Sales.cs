﻿using DesktopDesign.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace DesktopDesign.DB
{
	public class Sales
	{
        SqlConnection con;
        SqlDataReader reader = null;
        public void Save(CustomerBuy cb)
		{
            con = new SqlConnection((new Connection()).connectionString);
            SqlCommand command = new SqlCommand("spCustomerBuy", con);
            command.Parameters.Add(new SqlParameter("@Invoice", cb.Invoice));
            command.Parameters.Add(new SqlParameter("@Total", cb.Total));
            command.Parameters.Add(new SqlParameter("@TotalDiscount", cb.TotalDiscount));
            command.Parameters.Add(new SqlParameter("@Vat", cb.Vat));
            command.Parameters.Add(new SqlParameter("@Paid", cb.Paid));
            command.Parameters.Add(new SqlParameter("@GivenNote", cb.PaidNote));
            command.Parameters.Add(new SqlParameter("@PaymnetMethod", cb.PaymnetMethod));
            command.Parameters.Add(new SqlParameter("@InputDate", cb.InputDateTime));
            command.Parameters.Add(new SqlParameter("@customerName", cb.Customer.Name));
            command.Parameters.Add(new SqlParameter("@customerMobile", cb.Customer.Mobile));

            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("ProductId"));
            dt.Columns.Add(new DataColumn("Quantity"));
            dt.Columns.Add(new DataColumn("Discount"));

            DataRow dr;
            foreach (var i in cb.CustomerBuyDetailsList)
            {
                dr = dt.NewRow();
                dr[0] = i.ProductId;
                dr[1] = i.Quantity;
                dr[2] = i.Discount;

                dt.Rows.Add(dr);
            }

            command.Parameters.Add(new SqlParameter("@customerBuyDetailsTemp", dt));

            command.CommandType = CommandType.StoredProcedure;
            con.Open();
            try
            {
                int result = command.ExecuteNonQuery();

                //if (Convert.ToBoolean(result))
                //{
                //    return new JsonResult { Data = new { status = true } };
                //}
                //else
                //{
                //    return new JsonResult { Data = new { status = false } };
                //}
            }
            catch (Exception ex)
            {
                string message = ex.ToString();
                //return new JsonResult { Data = new { status = false } };
            }
            finally
            {
                con.Close();
            }
        }
	}
}
