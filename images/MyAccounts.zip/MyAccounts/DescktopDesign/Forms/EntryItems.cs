﻿using DesktopDesign.Classes;
using DesktopDesign.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesktopDesign.Forms
{
	public partial class EntryItems : Form
	{
		List<ItemGrid> allProduct;
		List<string> productName;
		long productId;
		List<long> productIds;
		void Initial()
		{
			allProduct = new List<ItemGrid>();
			allProduct = Product.GetProducts();

			lblMessage.Text = "";
			txtName.AutoCompleteMode = AutoCompleteMode.None;
			txtName.AutoCompleteSource = AutoCompleteSource.CustomSource;
			productName = new List<string>();
			this.ActiveControl = txtName;
			productName = allProduct.Select(w => w.ItemName).ToList();
			hideResults();
			this.lbAutoComplete.Location = new System.Drawing.Point(58, 94);
			this.lbAutoComplete.Size = new System.Drawing.Size(279, 82);
			txtCode.Text = "item-#" + getProductId();
		}
		public EntryItems()
		{
			InitializeComponent();

			Initial();
		}
		long getProductId()
		{
			Connection con = new Connection();
			DataTable dt;
			string cmd = "SELECT MAX(ItemId) FROM ITEM";
			dt = con.GetData(cmd);
			long id = dt.Rows.Count > 0 && !string.IsNullOrEmpty(dt.Rows[0][0].ToString()) ? Convert.ToInt64(dt.Rows[0][0]) : 0;
			return id;
		}
		private void txtName_TextChanged(object sender, EventArgs e)
		{
			lbAutoComplete.Items.Clear();
			productIds = new List<long>();
			productId = 0;
			if (txtName.Text.Length == 0)
			{
				hideResults();
				return;
			}

			if (!String.IsNullOrEmpty(txtName.Text.Trim()))
			{
				string pattern = @"\b\w*" + txtName.Text.Trim() + @"+\w*\b";
				lbAutoComplete.Items.Clear();

				foreach (ItemGrid s in allProduct.Where(p => Regex.IsMatch(p.ItemName, pattern, RegexOptions.IgnoreCase)))
				{
					lbAutoComplete.Items.Add(s.ItemName);
					productIds.Add(s.ItemId);
				}
				if (lbAutoComplete.Items.Count > 0)
				{
					lbAutoComplete.Visible = true;
				}
				else
				{
					hideResults();
				}
			}
		}
		void lbAutoComplete_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			productId = 0;
			if (lbAutoComplete.SelectedIndex > -1)
			{
				int selectedIndex = lbAutoComplete.SelectedIndex;
				productId = productIds[selectedIndex];
				txtName.Text = lbAutoComplete.Items[selectedIndex].ToString();
			}
			
			hideResults();
		}

		void hideResults()
		{
			lbAutoComplete.Visible = false;
		}

		void Clear()
		{
			txtCode.Text = "item-#" + getProductId();
			txtName.Text = "";
			cmbUnit.SelectedIndex = -1;
			txtPrice.Text = "0.00";
			txtDiscount.Text = "0.00";
			txtSellPrice.Text = "0.00";
			txtQuantity.Text = "0.00000";
			this.ActiveControl = txtName;
			hideResults();
		}

		private void btnClear_Click(object sender, EventArgs e)
		{
			Clear();
		}
		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			//const int WM_KEYDOWN = 0x100;
			//const int WM_ENTERIDLE = 0x121;
			//const int VK_DELETE = 0x2e;
			//const int WM_PASTE = 0x302;
			//bool delete = msg.Msg == WM_KEYDOWN && (int)msg.WParam == VK_DELETE;

			//Control c = Control.FromHandle(msg.HWnd);
			//string name = c.Name;

			if (keyData == (Keys.Enter))
			{
				SendKeys.Send("{TAB}");
			}

			return base.ProcessCmdKey(ref msg, keyData);
		}

		private void btnSave_Click(object sender, EventArgs e)
		{
			try
			{
				ItemGrid item = new ItemGrid();
				item.PurchasePrice = Convert.ToDouble(txtPrice.Value);
				item.OtherCost = Convert.ToDouble(txtOtherPrice.Value);
				item.SellPrice = Convert.ToDouble(txtSellPrice.Value);
				item.DiscountPrice = txtDiscount.Value.ToString() == "" || txtDiscount.Value == 0 ? item.SellPrice : Convert.ToDouble(txtDiscount.Value);
				item.ItemCode = txtCode.Text;
				item.ItemName = txtName.Text;
				item.Quantity = Convert.ToDouble(txtQuantity.Value);
				item.UnitID = Convert.ToInt16(cmbUnit.SelectedValue);
				Product.Save(item);
				lblMessage.Text = "Save Successfully";
				getItems();
				getProductId();
			}
			catch (Exception ex)
			{
				lblMessage.Text = "Something Goes Wrong!";
			}
		}
		void getItems()
		{
			//bool flag = false;
			Connection con = new Connection();
			string cmd = @"SELECT ItemId, ITEMCODE, ITEMNAME, QUANTITY, PurchasePrice,
				 OTHERCost, DISCOUNTPRICE, SellPRICE FROM ITEM";
			DataTable dt = con.GetData(cmd);
			dgItems.DataSource = dt;
			dgItems.AutoGenerateColumns = false;
			dgItems.Columns[0].Visible = false;
			dgItems.Refresh();
		}

		private void EntryItems_Load(object sender, EventArgs e)
		{
			getItems();

			DataGridViewLinkColumn Editlink = new DataGridViewLinkColumn();
			Editlink.UseColumnTextForLinkValue = true;
			Editlink.HeaderText = "Edit";
			Editlink.DataPropertyName = "lnkColumn";
			Editlink.LinkBehavior = LinkBehavior.SystemDefault;
			Editlink.Text = "Edit";
			dgItems.Columns.Add(Editlink);

			DataGridViewLinkColumn Deletelink = new DataGridViewLinkColumn();
			Deletelink.UseColumnTextForLinkValue = true;
			Deletelink.HeaderText = "Delete";
			Deletelink.DataPropertyName = "lnkColumn";
			Deletelink.LinkBehavior = LinkBehavior.SystemDefault;
			Deletelink.Text = "Delete";
			dgItems.Columns.Add(Deletelink);
		}

		private void dgItems_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			try
			{
				if (e.ColumnIndex == 8)
				{
					long id = Convert.ToInt64(dgItems.Rows[e.RowIndex].Cells[0].Value.ToString());
					string name = dgItems.Rows[e.RowIndex].Cells[1].Value.ToString();
					string mobile = dgItems.Rows[e.RowIndex].Cells[2].Value.ToString();
					string email = dgItems.Rows[e.RowIndex].Cells[3].Value.ToString();
					string address = dgItems.Rows[e.RowIndex].Cells[4].Value.ToString();
				}
				else if (e.ColumnIndex == 9)
				{
					long id = Convert.ToInt64(dgItems.Rows[e.RowIndex].Cells[0].Value.ToString());
					string name = dgItems.Rows[e.RowIndex].Cells[1].Value.ToString();
					DialogResult dr = MessageBox.Show("Are You Sure You Want To Delete " + Environment.NewLine
						+ name + "'s Informations", "Warning!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
					if (dr.ToString() == "Yes")
					{
						//string sql = "DELETE FROM ITEM WHERE Id = " + id;
						//bool flag = false;
						if (Product.Delete(id))
						{
							//sql = "DELETE FROM DoctorDetails WHERE DoctorId = " + id;
							//if (crud.Delete(sql))
							//{
							//	flag = true;
							//}
							getItems();
						}
						else
						{
							MessageBox.Show("Data couldn't delete!");
						}
						//if (!flag)
						//{
						//	MessageBox.Show("Data couldn't delete!");
						//}
						//else
						//{
						//	getItems();
						//}
					}
				}
			}
			catch (Exception ex)
			{
				ex.ToString();
			}
		}
	}
}
