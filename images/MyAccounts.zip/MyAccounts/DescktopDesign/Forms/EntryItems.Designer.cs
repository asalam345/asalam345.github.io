﻿namespace DesktopDesign.Forms
{
	partial class EntryItems
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label8 = new System.Windows.Forms.Label();
			this.txtOtherPrice = new System.Windows.Forms.NumericUpDown();
			this.label7 = new System.Windows.Forms.Label();
			this.txtDiscount = new System.Windows.Forms.NumericUpDown();
			this.label6 = new System.Windows.Forms.Label();
			this.txtSellPrice = new System.Windows.Forms.NumericUpDown();
			this.label5 = new System.Windows.Forms.Label();
			this.lblMessage = new System.Windows.Forms.Label();
			this.lbAutoComplete = new System.Windows.Forms.ListBox();
			this.cmbUnit = new System.Windows.Forms.ComboBox();
			this.dgItems = new System.Windows.Forms.DataGridView();
			this.btnNew = new System.Windows.Forms.Button();
			this.btnExit = new System.Windows.Forms.Button();
			this.btnSave = new System.Windows.Forms.Button();
			this.txtQuantity = new System.Windows.Forms.NumericUpDown();
			this.txtPrice = new System.Windows.Forms.NumericUpDown();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.txtCode = new System.Windows.Forms.TextBox();
			this.txtName = new System.Windows.Forms.TextBox();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.txtOtherPrice)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.txtDiscount)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.txtSellPrice)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dgItems)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.txtQuantity)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.txtPrice)).BeginInit();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.label8);
			this.groupBox1.Controls.Add(this.txtOtherPrice);
			this.groupBox1.Controls.Add(this.label7);
			this.groupBox1.Controls.Add(this.txtDiscount);
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.txtSellPrice);
			this.groupBox1.Controls.Add(this.label5);
			this.groupBox1.Controls.Add(this.lblMessage);
			this.groupBox1.Controls.Add(this.lbAutoComplete);
			this.groupBox1.Controls.Add(this.cmbUnit);
			this.groupBox1.Controls.Add(this.dgItems);
			this.groupBox1.Controls.Add(this.btnNew);
			this.groupBox1.Controls.Add(this.btnExit);
			this.groupBox1.Controls.Add(this.btnSave);
			this.groupBox1.Controls.Add(this.txtQuantity);
			this.groupBox1.Controls.Add(this.txtPrice);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.txtCode);
			this.groupBox1.Controls.Add(this.txtName);
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Margin = new System.Windows.Forms.Padding(15, 4, 15, 10);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
			this.groupBox1.Size = new System.Drawing.Size(795, 517);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Item Entry";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(257, 145);
			this.label8.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(43, 18);
			this.label8.TabIndex = 23;
			this.label8.Text = "Unit:";
			// 
			// txtOtherPrice
			// 
			this.txtOtherPrice.DecimalPlaces = 2;
			this.txtOtherPrice.ImeMode = System.Windows.Forms.ImeMode.On;
			this.txtOtherPrice.Location = new System.Drawing.Point(403, 84);
			this.txtOtherPrice.Margin = new System.Windows.Forms.Padding(5, 4, 50, 4);
			this.txtOtherPrice.Name = "txtOtherPrice";
			this.txtOtherPrice.Size = new System.Drawing.Size(139, 24);
			this.txtOtherPrice.TabIndex = 21;
			this.txtOtherPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(251, 86);
			this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(96, 18);
			this.label7.TabIndex = 22;
			this.label7.Text = "Other Cost:";
			// 
			// txtDiscount
			// 
			this.txtDiscount.DecimalPlaces = 2;
			this.txtDiscount.ImeMode = System.Windows.Forms.ImeMode.On;
			this.txtDiscount.Location = new System.Drawing.Point(403, 116);
			this.txtDiscount.Margin = new System.Windows.Forms.Padding(5, 4, 50, 4);
			this.txtDiscount.Name = "txtDiscount";
			this.txtDiscount.Size = new System.Drawing.Size(139, 24);
			this.txtDiscount.TabIndex = 21;
			this.txtDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(251, 116);
			this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(142, 18);
			this.label6.TabIndex = 22;
			this.label6.Text = "Discounted Price:";
			// 
			// txtSellPrice
			// 
			this.txtSellPrice.DecimalPlaces = 2;
			this.txtSellPrice.ImeMode = System.Windows.Forms.ImeMode.On;
			this.txtSellPrice.Location = new System.Drawing.Point(106, 114);
			this.txtSellPrice.Margin = new System.Windows.Forms.Padding(5, 4, 50, 4);
			this.txtSellPrice.Name = "txtSellPrice";
			this.txtSellPrice.Size = new System.Drawing.Size(141, 24);
			this.txtSellPrice.TabIndex = 19;
			this.txtSellPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(18, 116);
			this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(85, 18);
			this.label5.TabIndex = 20;
			this.label5.Text = "Sell Price:";
			// 
			// lblMessage
			// 
			this.lblMessage.AutoSize = true;
			this.lblMessage.Location = new System.Drawing.Point(345, 0);
			this.lblMessage.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.lblMessage.Name = "lblMessage";
			this.lblMessage.Size = new System.Drawing.Size(76, 18);
			this.lblMessage.TabIndex = 18;
			this.lblMessage.Text = "Message";
			// 
			// lbAutoComplete
			// 
			this.lbAutoComplete.FormattingEnabled = true;
			this.lbAutoComplete.ItemHeight = 18;
			this.lbAutoComplete.Location = new System.Drawing.Point(469, 52);
			this.lbAutoComplete.Name = "lbAutoComplete";
			this.lbAutoComplete.Size = new System.Drawing.Size(279, 22);
			this.lbAutoComplete.TabIndex = 5;
			this.lbAutoComplete.SelectedIndexChanged += new System.EventHandler(this.lbAutoComplete_SelectedIndexChanged);
			// 
			// cmbUnit
			// 
			this.cmbUnit.FormattingEnabled = true;
			this.cmbUnit.Location = new System.Drawing.Point(403, 145);
			this.cmbUnit.Name = "cmbUnit";
			this.cmbUnit.Size = new System.Drawing.Size(94, 26);
			this.cmbUnit.TabIndex = 11;
			// 
			// dgItems
			// 
			this.dgItems.BackgroundColor = System.Drawing.SystemColors.Control;
			this.dgItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgItems.Location = new System.Drawing.Point(12, 278);
			this.dgItems.Name = "dgItems";
			this.dgItems.Size = new System.Drawing.Size(775, 239);
			this.dgItems.TabIndex = 5;
			this.dgItems.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItems_CellClick);
			// 
			// btnNew
			// 
			this.btnNew.ForeColor = System.Drawing.Color.Blue;
			this.btnNew.Location = new System.Drawing.Point(104, 224);
			this.btnNew.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
			this.btnNew.Name = "btnNew";
			this.btnNew.Size = new System.Drawing.Size(125, 47);
			this.btnNew.TabIndex = 4;
			this.btnNew.Text = "ADD NEW";
			this.btnNew.UseVisualStyleBackColor = true;
			this.btnNew.Click += new System.EventHandler(this.btnClear_Click);
			// 
			// btnExit
			// 
			this.btnExit.ForeColor = System.Drawing.Color.Red;
			this.btnExit.Location = new System.Drawing.Point(526, 224);
			this.btnExit.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
			this.btnExit.Name = "btnExit";
			this.btnExit.Size = new System.Drawing.Size(89, 47);
			this.btnExit.TabIndex = 4;
			this.btnExit.Text = "Exit";
			this.btnExit.UseVisualStyleBackColor = true;
			// 
			// btnSave
			// 
			this.btnSave.ForeColor = System.Drawing.Color.Green;
			this.btnSave.Location = new System.Drawing.Point(239, 224);
			this.btnSave.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(182, 47);
			this.btnSave.TabIndex = 3;
			this.btnSave.Text = "SAVE";
			this.btnSave.UseVisualStyleBackColor = true;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// txtQuantity
			// 
			this.txtQuantity.DecimalPlaces = 5;
			this.txtQuantity.Location = new System.Drawing.Point(106, 143);
			this.txtQuantity.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
			this.txtQuantity.Name = "txtQuantity";
			this.txtQuantity.Size = new System.Drawing.Size(141, 24);
			this.txtQuantity.TabIndex = 2;
			this.txtQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// txtPrice
			// 
			this.txtPrice.DecimalPlaces = 2;
			this.txtPrice.ImeMode = System.Windows.Forms.ImeMode.On;
			this.txtPrice.Location = new System.Drawing.Point(106, 84);
			this.txtPrice.Margin = new System.Windows.Forms.Padding(5, 4, 50, 4);
			this.txtPrice.Name = "txtPrice";
			this.txtPrice.Size = new System.Drawing.Size(141, 24);
			this.txtPrice.TabIndex = 1;
			this.txtPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(18, 145);
			this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(75, 18);
			this.label3.TabIndex = 1;
			this.label3.Text = "Quantity:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(18, 84);
			this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(52, 18);
			this.label2.TabIndex = 1;
			this.label2.Text = "Price:";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(18, 25);
			this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(53, 18);
			this.label4.TabIndex = 1;
			this.label4.Text = "Code:";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(18, 52);
			this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(57, 18);
			this.label1.TabIndex = 1;
			this.label1.Text = "Name:";
			// 
			// txtCode
			// 
			this.txtCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtCode.Cursor = System.Windows.Forms.Cursors.No;
			this.txtCode.Location = new System.Drawing.Point(106, 25);
			this.txtCode.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
			this.txtCode.Name = "txtCode";
			this.txtCode.ReadOnly = true;
			this.txtCode.Size = new System.Drawing.Size(98, 24);
			this.txtCode.TabIndex = 10;
			this.txtCode.Text = " item-00001";
			// 
			// txtName
			// 
			this.txtName.Location = new System.Drawing.Point(106, 52);
			this.txtName.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
			this.txtName.Name = "txtName";
			this.txtName.Size = new System.Drawing.Size(317, 24);
			this.txtName.TabIndex = 0;
			this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
			// 
			// EntryItems
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 529);
			this.Controls.Add(this.groupBox1);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
			this.MaximizeBox = false;
			this.Name = "EntryItems";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Load += new System.EventHandler(this.EntryItems_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.txtOtherPrice)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.txtDiscount)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.txtSellPrice)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dgItems)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.txtQuantity)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.txtPrice)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.NumericUpDown txtQuantity;
		private System.Windows.Forms.NumericUpDown txtPrice;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtName;
		private System.Windows.Forms.DataGridView dgItems;
		private System.Windows.Forms.Button btnNew;
		private System.Windows.Forms.Button btnExit;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtCode;
		private System.Windows.Forms.ComboBox cmbUnit;
		private System.Windows.Forms.ListBox lbAutoComplete;
		private System.Windows.Forms.Label lblMessage;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.NumericUpDown txtOtherPrice;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.NumericUpDown txtDiscount;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.NumericUpDown txtSellPrice;
		private System.Windows.Forms.Label label5;
	}
}