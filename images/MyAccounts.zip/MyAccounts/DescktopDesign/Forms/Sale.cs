﻿using DesktopDesign.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using DesktopDesign.DB;

namespace DesktopDesign.Forms
{
	public partial class Sale : Form
	{
		List<ItemGrid> allProduct;
		List<string> productName;
		//long productId;
		List<long> productIds;
		List<ItemGrid> itemGrid = new List<ItemGrid>();
		List<ItemGrid> autoCompleteItems = new List<ItemGrid>();
		Dictionary<long, ItemGrid> selectedItems = new Dictionary<long, ItemGrid>();
		ItemGrid aItemGrid;
		void Initial()
		{
			allProduct = new List<ItemGrid>();
			allProduct = Product.GetProducts();


			//lblMessage.Text = "";
			txtName.AutoCompleteMode = AutoCompleteMode.None;
			txtName.AutoCompleteSource = AutoCompleteSource.CustomSource;
			productName = new List<string>();
			this.ActiveControl = txtName;
			productName = allProduct.Select(w => w.ItemName).ToList();
			productIds = allProduct.Select(w => w.ItemId).ToList();
			hideResults();


			gd.Rows.Clear();
			gd.Columns.Clear();
			gd.Columns.Add("cItemId", "");
			gd.Columns.Add("cSerial", "#");
			gd.Columns.Add("cItemName", "Item Name");
			gd.Columns.Add("cQuantity", "Quantity");
			gd.Columns.Add("cPrice", "Price");
			gd.Columns.Add("cAmount", "Amount");
			gd.Columns[0].Visible = false;
			gd.Columns[1].ReadOnly = true;
			gd.Columns[2].ReadOnly = true;
			gd.Columns[4].ReadOnly = true;
			gd.Columns[5].ReadOnly = true;
			DataGridViewLinkColumn Deletelink = new DataGridViewLinkColumn();
			Deletelink.UseColumnTextForLinkValue = true;
			Deletelink.HeaderText = "Delete";
			Deletelink.DataPropertyName = "lnkColumn";
			Deletelink.LinkBehavior = LinkBehavior.NeverUnderline;
			Deletelink.Text = "x";
			Deletelink.LinkColor = Color.Red;
			gd.Columns.Add(Deletelink);
		}
		public Sale()
		{
			InitializeComponent();
			Initial();
			gd.AutoGenerateColumns = false;
			gd.AllowUserToAddRows = false;
		}
		private void txt_KeyUp(object sender, KeyEventArgs e)
		{
			Calculation();
		}
		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			//const int WM_KEYDOWN = 0x100;
			//const int WM_ENTERIDLE = 0x121;
			//const int VK_DELETE = 0x2e;
			//const int WM_PASTE = 0x302;
			//bool delete = msg.Msg == WM_KEYDOWN && (int)msg.WParam == VK_DELETE;

			//Control c = Control.FromHandle(msg.HWnd);
			//string name = c.Name;

			if (keyData == (Keys.Enter))
			{
				SendKeys.Send("{TAB}");
			}

			return base.ProcessCmdKey(ref msg, keyData);
		}
		private void txtName_TextChanged(object sender, EventArgs e)
		{
			lbAutoComplete.Items.Clear();
			productIds = new List<long>();
			autoCompleteItems = new List<ItemGrid>();
			//productId = 0;
			if (txtName.Text.Length == 0)
			{
				hideResults();
				return;
			}

			if (!String.IsNullOrEmpty(txtName.Text.Trim()))
			{
				string pattern = @"\b\w*" + txtName.Text.Trim() + @"+\w*\b";
				lbAutoComplete.Items.Clear();

				foreach (ItemGrid s in allProduct.Where(p => Regex.IsMatch(p.ItemName, pattern, RegexOptions.IgnoreCase)))
				{
					lbAutoComplete.Items.Add(s.ItemName);
					autoCompleteItems.Add(s);
				}
				if (lbAutoComplete.Items.Count > 0)
				{
					lbAutoComplete.Visible = true;
				}
				else
				{
					hideResults();
				}
			}
		}
		void lbAutoComplete_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			//productId = 0;
			if (lbAutoComplete.SelectedIndex > -1)
			{
				int selectedIndex = lbAutoComplete.SelectedIndex;
				aItemGrid = autoCompleteItems[selectedIndex];
				txtName.Text = lbAutoComplete.Items[selectedIndex].ToString();
				if (!selectedItems.ContainsKey(aItemGrid.ItemId))
				{
					selectedItems.Add(aItemGrid.ItemId, aItemGrid);
					LoadGrid(aItemGrid);
				}
				//gd.DataSource = selectedItems;
				//gd.Refresh();
			}
			Calculation();
			hideResults();
		}
		void hideResults()
		{
			lbAutoComplete.Visible = false;
		}
		//private void LoadGrid(Dictionary<long, ItemGrid> ds)
		private void LoadGrid(ItemGrid ds)
		{
			
			//gd.DataSource = ds;
			int count = 0;
			//foreach (ItemGrid i in ds.Values) {
			//ItemGrid i = ds.Values.Last();
				gd.Rows.Add(ds.ItemId, ++count, ds.ItemName, 1, ds.SellPrice, ds.SellPrice);
				//gd.Rows.Add(++count);
				//gd.Rows.Add(i.ItemName);
				//gd.Rows.Add(1);
				//gd.Rows.Add(i.SellPrice);
				//gd.Rows.Add(i.SellPrice);
				//gd.Columns[0].Visible = false;
				//	gd.Columns[1].Visible = false;
				//	gd.Columns[3].Visible = false;
				//	gd.Columns[4].Visible = false;
				//	gd.Columns[5].Visible = false;
				//	gd.Columns[6].Visible = false;

				//	gd.Columns[10].Visible = false;
				//	gd.Columns[11].Visible = false;
				//	gd.Columns[12].Visible = false;
				//	gd.Columns[13].Visible = false;
				//	gd.Columns[14].Visible = false;
				//	gd.Columns[15].Visible = false;

				//	gd.Columns[7].HeaderText = "Quantity";
				//	gd.Columns[8].HeaderText = "Price";

				//	gd.Columns[2].ReadOnly = true;
				//	gd.Columns[8].ReadOnly = true;
				//	gd.Columns[9].ReadOnly = true;

				//	gd.Columns.Add("Amount", i.SellPrice.ToString());
				//DataGridViewLinkColumn Editlink = new DataGridViewLinkColumn();
				//Editlink.UseColumnTextForLinkValue = true;
				//Editlink.HeaderText = "Edit";
				//Editlink.DataPropertyName = "lnkColumn";
				//Editlink.LinkBehavior = LinkBehavior.SystemDefault;
				//Editlink.Text = "Edit";
				//gd.Columns.Add(Editlink);
			//}
			
			gd.Refresh();
		}

		
		private void btnReloadItem_Click(object sender, EventArgs e)
		{
			Initial();
		}

		private void gd_CellEndEdit(object sender, DataGridViewCellEventArgs e)
		{
			//int i = gd.CurrentCell.RowIndex;.
			//int j = gd.CurrentCell.ColumnIndex;
			//string a = gd.Rows[i].Cells[j].Value.ToString();
			if (e.ColumnIndex == 3)
			{
				long id = Convert.ToInt64(gd.Rows[e.RowIndex].Cells[0].Value.ToString());
				double quantity = Convert.ToDouble(gd.Rows[e.RowIndex].Cells[3].Value.ToString());
				if(quantity > selectedItems[id].Quantity)
				{
					MessageBox.Show("Not Sufficient Amount");
					return;
				}
				double price = Convert.ToDouble(gd.Rows[e.RowIndex].Cells[4].Value.ToString());
				gd.Rows[e.RowIndex].Cells[5].Value = quantity * price;
				Calculation();
			}
		}
		void Calculation()
		{
			try
			{
				double amount = 0;
				foreach (DataGridViewRow d in gd.Rows)
				{
					amount += Convert.ToDouble(d.Cells[5].Value);
				}
				txtTotal.Text = amount.ToString();
				double discount = String.IsNullOrEmpty(txtDiscount.Text) ? 0 : Convert.ToDouble(txtDiscount.Text);
				double vat = String.IsNullOrEmpty(txtVat.Text) ? 0 : Convert.ToDouble(txtVat.Text);
				double paid = String.IsNullOrEmpty(txtPaid.Text) ? 0 : Convert.ToDouble(txtPaid.Text);
				amount = amount + vat;
				double netPayable = amount - discount;
				txtPayable.Text = netPayable.ToString();
				double due = netPayable - paid;
				txtDue.Text = due.ToString();
				double paidNote = Convert.ToDouble(txtPaidNote.Text);
				double change = paidNote - paid;
				txtChange.Text = change.ToString();
			}
			catch (Exception ex)
			{
				ex.ToString();
			}
			
		}

		private void gd_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.ColumnIndex == 6)
			{
				long id = Convert.ToInt64(gd.Rows[e.RowIndex].Cells[0].Value.ToString());
				string name = gd.Rows[e.RowIndex].Cells[2].Value.ToString();
				DialogResult dr = MessageBox.Show("Are You Sure You Want To Delete " + Environment.NewLine
					+ name + "'s Informations", "Warning!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
				if (dr.ToString() == "Yes")
				{
					selectedItems.Remove(id);
					gd.Rows.RemoveAt(e.RowIndex);
					Calculation();
				}
			}
		}

		private void btnOk_Click(object sender, EventArgs e)
		{
			try
			{
				CustomerBuy cb = new CustomerBuy();
				cb.Customer = new Customer();
				List<CustomerBuyDetails> cbdList = new List<CustomerBuyDetails>();
				cb.Customer.Name = txtCustomerName.Text.Trim() == "Customer Name" ? "" : txtCustomerName.Text.Trim();
				cb.Customer.Mobile = String.IsNullOrEmpty(txtCustomerMobile.Text.Trim()) || txtCustomerMobile.Text.Trim() == "Customer Mobile" || txtCustomerMobile.Text.Length > 11 ? "" : txtCustomerMobile.Text.Trim();
				cb.InputDateTime = dt.Text.Trim();
				cb.Invoice = txtInvoice.Text.Trim();
				cb.Paid = Convert.ToDouble(txtPaid.Text);
				cb.TotalDiscount = Convert.ToDouble(txtDiscount.Text);
				cb.Vat = Convert.ToDouble(txtVat.Text);
				cb.PaidNote = Convert.ToDouble(txtPaidNote.Text);
				cb.Total = Convert.ToDouble(txtTotal.Text);
				cb.PaymnetMethod = Convert.ToInt16(comPaymentMethod.SelectedValue);
				foreach (ItemGrid i in selectedItems.Values)
				{
					CustomerBuyDetails cbd = new CustomerBuyDetails();
					cbd.Discount = 0;
					cbd.ProductId = i.ItemId;
					cbd.Quantity = i.Quantity;
					cbdList.Add(cbd);
				}
				cb.CustomerBuyDetailsList = cbdList;
				Sales sales = new Sales();
				sales.Save(cb);
			}
			catch (Exception ex)
			{

			}
			finally
			{
				Reset();
			}
		}
		string initialValue()
		{
			return "0";
		}
		void GetInvoiceNumber()
		{
			DateTime dateTime = DateTime.Now;
			txtInvoice.Text = dateTime.ToFileTime().ToString();
		}
		void Reset()
		{
			GetInvoiceNumber();
			gd.Rows.Clear();
			txtName.Text = "Item Name";
			txtCustomerName.Text = "Customer Name";
			txtCustomerMobile.Text = "Customer Mobile";
			txtTotal.Text = initialValue();
			txtDiscount.Text = initialValue();
			txtVat.Text = initialValue();
			txtPayable.Text = initialValue();
			txtPaid.Text = initialValue();
			txtDue.Text = initialValue();
			txtPaidNote.Text = initialValue();
			txtChange.Text = initialValue();
		}
		private void btnReset_Click(object sender, EventArgs e)
		{
			Reset();
		}

		private void Sale_Load(object sender, EventArgs e)
		{
			comPaymentMethod.Text = comPaymentMethod.Items[0].ToString();
			GetInvoiceNumber();
		}

		private void txt_Click(object sender, EventArgs e)
		{
			TextBox txt = (sender as TextBox);
			string s = (sender as TextBox).Name;
			switch (s)
			{
				case "txtName":
				case "txtCustomerMobile":
				case "txtCustomerName":
				case "txtDiscount":
				case "txtVat":
				case "txtPaid":
				case "txtPaidNote":
					txt.SelectAll();
					break;

			}
		}
	}
}
