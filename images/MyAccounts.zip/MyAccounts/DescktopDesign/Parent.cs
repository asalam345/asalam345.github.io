﻿using DesktopDesign.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DesktopDesign
{
	public partial class Parent : Form
	{
		public Parent()
		{
			InitializeComponent();
		}

		private void Parent_Load(object sender, EventArgs e)
		{
			Sale sales = new Sale();
			sales.MdiParent = this;
			sales.Show();
		}

		private void productToolStripMenuItem_Click(object sender, EventArgs e)
		{
			EntryItems entryItem = new EntryItems();
			entryItem.MdiParent = this;
			entryItem.Show();
		}

		private void salesToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Sale sales = new Sale();
			sales.MdiParent = this;
			sales.Show();
		}
	}
}
